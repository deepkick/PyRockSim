第２章のロケットシミュレーションプログラムのソースコードは
以下のGitHubレポジトリを参照してください。

https://github.com/pyjbooks/PyRockSim.git

