# ファイル名: module_1.py """
print("module_1 is imported.")
wgt = 60.5  # 初期体重 [kg]


def teacher(x):
    if x > 60:
        print("体重オーバーです")
    else:
        print("適正体重です")
